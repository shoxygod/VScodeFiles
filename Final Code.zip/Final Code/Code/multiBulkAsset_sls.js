import { LightningElement, track } from 'lwc';
import BulkMultipleAssetIconsZip from '@salesforce/resourceUrl/BulkMultipleAssetIconsZip';

export default class testAssetAndDetailPage extends LightningElement {

    @track iconClose;
    @track iconNotes;
    @track iconDecreament;
    @track iconIncreament;


    constructor(){
        super();

        this.iconClose = BulkMultipleAssetIconsZip +'/BulkMultipleAssetIconsZip/close-icon.png';
        this.iconNotes = BulkMultipleAssetIconsZip +'/BulkMultipleAssetIconsZip/notes-icon.png';
        this.iconDecreament = BulkMultipleAssetIconsZip +'/BulkMultipleAssetIconsZip/decreament-icon.png';
        this.iconIncreament = BulkMultipleAssetIconsZip +'/BulkMultipleAssetIconsZip/increament-icon.png';
    }

    increamentValue()
    {
        var value = parseInt(this.template.querySelector('lightning-input[data-id="number"]').value);
        if(value > 0){
            value++;
        }
        console.log('Function ran');
    }     

}