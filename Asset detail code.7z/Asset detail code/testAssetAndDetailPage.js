import { LightningElement, track, api} from 'lwc';
import AssetDetail__c from '@salesforce/schema/AssetDetail__c';
/*import enquiryCustomCss from '@salesforce/resourceUrl/enquiryCustomCss';

import { loadStyle } from 'lightning/platformResourceLoader';*/

export default class TestAssetandDetailPage extends LightningElement {

    @track rectanglecopy;
    @track rectanglecopy1;
    @track switchTabsData;
    @track switchTabsFontColor;
    @track actualProformaData;


    constructor(){
        super();
        this.rectanglecopy = "Rectangle-Copy";
        this.rectanglecopy1= "Rectangle-Copy1";
        this.switchTabsData = true;
        this.switchTabsFontColor = "whiteh5regularcentre";

    }

    @api
    myRecordId;

    get acceptedFormats() {
        return ['.pdf', '.png'];
    }

    handleUploadFinished(event) {
        // Get the list of uploaded files
        const uploadedFiles = event.detail.files;
        alert('No. of files uploaded : ' + uploadedFiles.length);
    }


    /*stylesLoaded=false;
    connectedCallback(){
        if(!this.stylesLoaded) {

            Promise.all([loadStyle(this, enquiryCustomCss)])
    
            .then(() => {
    
                console.log('loaded');
    
                this.stylesLoaded = true;
    
            })
    
            .catch(
    
                error => {
    
                    console.log('error in loading');
    
                });
    
        }
    }*/



    fetchUserProformaInputOnClickButton(){

        

    }




    switchTabs(event){
        console.log("method called");

        if(event.currentTarget.dataset.id == 'SearchByName'){
            this.rectanglecopy = "Rectangle-Copy";
            this.rectanglecopy1= "Rectangle-Copy1";
            this.switchTabsData = true;
        }
        else{
            console.log("MMV Called");
            this.rectanglecopy = "Rectangle-Copy1";
            this.rectanglecopy1= "Rectangle-Copy";
            this.switchTabsData = false;

        }

    }

    renderedCallback()
    {
        const style2=document.createElement('style');
        style2.innerText=`c-test-asset-and-detail-page .combo-input .slds-combobox__input{
        background-color:#EAECFD
    }`;
    this.template.querySelector('.combo-input').appendChild(style2);
    }

    fetchUserProformaInput() {
        let proformaInvoiceNumber = this.template.querySelector("lightning-input[data-id=proformaInvoiceNumber]").value;
        console.log("this is string:",  proformaInvoiceNumber);
        let proformaInvoiceValue = this.template.querySelector("lightning-input[data-id=proformaInvoiceValue]").value;
        let proformaInvoiceDate =  this.template.querySelector("lightning-input[data-id=proformaInvoiceDate]").value;
        RemoteControllerExample.RemoteControllerExampleMethod(proformaInvoiceNumber,proformaInvoiceValue,proformaInvoiceDate,function(result,event){
            if(event.status)
            {console.log(result);}
        });
        
    } 
    handleclick(){
        this.template.querySelector('input').click();
    }
}